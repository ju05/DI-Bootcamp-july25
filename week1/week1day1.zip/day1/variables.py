#naming variables best practices

my_age = 35
my_name = "Juliana"

# input() function = a way of getting "user" input

user_name = input('What\'s your name:' )
print(user_name)

#VERY IMPORTANT INFO ABOUT INPUT: THE VALUE OF IT IS BY DEFAULT A STRING

user_age = int(input("what's your age? "))
print( 'in 123879 of years you will be ',  user_age + 123879, 'years old')

# f' string = string that is formated to be more readable

print(f'In 123879 of years you will be {user_age + 123879} years old')





